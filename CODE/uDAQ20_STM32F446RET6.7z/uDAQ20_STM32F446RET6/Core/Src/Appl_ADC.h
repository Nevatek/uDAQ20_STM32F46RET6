/*
 * Appl_ADC.h
 *
 *  Created on: Jun 3, 2025
 *      Author: aldri
 */

#ifndef SRC_APPL_ADC_H_
#define SRC_APPL_ADC_H_

void Appl_HandlerAdc_Init(void);
void Appl_HandlerAdc(void);
#endif /* SRC_APPL_ADC_H_ */
